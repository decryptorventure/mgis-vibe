# @frontend-team/ui-kit

Shared React UI component library + design system tokens cho tất cả các frontend projects trong team.

## 📦 Cài đặt

```bash
npm install @frontend-team/ui-kit
```

**Peer dependencies:** React 18 hoặc React 19

## 🚀 Quick Start

### 1. Import CSS (bắt buộc)

Import một lần duy nhất trong entry file của app (`main.tsx`, `_app.tsx`, `layout.tsx`):

```tsx
import "@frontend-team/ui-kit/style.css";
```

### 2. Thêm Toaster vào root app (nếu dùng Toast)

```tsx
import { Toaster } from "@frontend-team/ui-kit";

function App() {
  return (
    <>
      <Toaster />
      {/* rest of app */}
    </>
  );
}
```

### 3. Sử dụng components

```tsx
import { Button, Input, Badge, Modal, Select, toast } from "@frontend-team/ui-kit";
```

### 4. Dark mode

Thêm class `.dark` vào root element để enable dark mode:

```tsx
<html className="dark">...</html>
```

Hoặc dùng hook đi kèm:

```tsx
import { useDarkMode } from "@frontend-team/ui-kit";

function ThemeToggle() {
  const { isDark, toggle } = useDarkMode();
  return <button onClick={toggle}>{isDark ? "Light" : "Dark"}</button>;
}
```

---

## 🧩 Components

| Component | Mô tả |
|-----------|-------|
| `Button` | Nút bấm với 6 variants, loading state, icon-only |
| `Avatar` | Ảnh đại diện (image/icon/text fallback), 6 sizes |
| `Input` | Text input với 4 variants và 5 sizes |
| `Spinner` | Loading spinner standalone |
| `Badge` | Label nhỏ hiển thị status, count, category |
| `Checkbox` | Checkbox với label/description, hỗ trợ indeterminate |
| `RadioGroup` | Nhóm radio buttons |
| `Switch` | Toggle on/off |
| `Modal` | Dialog/modal với portal, focus trap |
| `Toaster` | Container để hiển thị toast notifications |
| `Tooltip` | Tooltip khi hover/focus |
| `Popover` | Dropdown tương tác |
| `Tabs` | Tab navigation |
| `Card` | Container card với Header/Content/Footer |
| `Accordion` | Collapsible sections |
| `Alert` | Inline notification với các trạng thái |
| `Breadcrumb` | Navigation breadcrumb trail |
| `Select` | Dropdown select với search, multi-select, virtual scroll |
| `Table` | Data table với sort, filter, row selection |
| `Pagination` | Điều hướng phân trang |
| `Progress` | Progress bar determinate/indeterminate |

---

## 🎨 Design Tokens

Sử dụng các CSS class được generate từ design system để style element bất kỳ:

```tsx
<div className="bg_primary border_secondary border radius_8 shadow-m p-4">
  <h2 className="text_primary font-bold">Heading</h2>
  <p className="text_tertiary">Description</p>
</div>
```

### Backgrounds
```
bg_primary · bg_secondary · bg_tertiary · bg_quaternary
bg_canvas_primary · bg_canvas_secondary · bg_canvas_tertiary · bg_canvas_quaternary
bg_interactive_primary · bg_interactive_secondary · bg_interactive_tertiary
bg_overlay · bg_inverse · bg_backdrop
bg_button_primary · bg_button_secondary · bg_button_tertiary
bg_input_fill · bg_input_fill_dim · bg_input_light
bg_accent_primary · bg_accent_primary_subtle · bg_accent_secondary · bg_accent_secondary_subtle
bg_success · bg_success_contrast · bg_error · bg_error_contrast
bg_warning · bg_warning_contrast · bg_info · bg_info_contrast
```

### Extended Color Palette (19 hues)

Hues: `orange` · `amber` · `yellow` · `lime` · `green` · `emerald` · `teal` · `cyan` · `sky` · `blue` · `indigo` · `violet` · `purple` · `fuchsia` · `pink` · `red` · `slate` · `gray` · `zinc`

| Pattern | CSS property | Ví dụ |
|---------|-------------|-------|
| `bg_{hue}_subtle` | background-color | `bg_blue_subtle` — nền nhạt cho tag, badge |
| `bg_{hue}_medium` | background-color | `bg_green_medium` — nền đậm hơn cho chart, progress |
| `fg_{hue}_strong` | color | `fg_red_strong` — text/icon đậm trên nền subtle |
| `fg_{hue}_accent` | color | `fg_blue_accent` — text/icon mid-tone cho link, icon |
| `border_{hue}` | border-color | `border_indigo` — viền theo hue |

```tsx
{/* Tag xanh lá */}
<span className="bg_green_subtle fg_green_strong border border_green radius_6 px-2 py-0.5 text-xs">
  Active
</span>

{/* Badge tím */}
<span className="bg_violet_subtle fg_violet_strong border border_violet radius_round px-2 py-0.5 text-xs">
  Beta
</span>
```

### Text & Icon
```
text_primary · text_secondary · text_tertiary · text_contrast
text_inverse_primary · text_inverse_secondary
icon_primary · icon_secondary · icon_tertiary
fg_accent_primary · fg_accent_secondary · fg_on_accent · fg_on_contrast
fg_link · fg_success · fg_error · fg_warning · fg_info
light_fixed · dim_fixed
```

### Border & Radius
```
border_primary · border_secondary · border_tertiary · border_contrast
border_input · border_input_opacity · border_button · border_dim_button
border_secondary_button · border_error_button
border_accent_primary · border_accent_primary_contrast
border_accent_secondary · border_accent_secondary_contrast
border_success · border_error
radius_2 · radius_4 · radius_6 · radius_8 · radius_12 · radius_16 · radius_24 · radius_round
```

### Shadows & Effects
```
shadow_xxs · shadow_xs · shadow_m · shadow_l · shadow_xl · shadow_xxl
backdrop_blur · outline_blue_focus · outline_orange_focus
```

### Interactive States (hover/active)
```tsx
<button className="bg_button_tertiary hover:state_bg_button_tertiary_soft active:state_bg_button_tertiary_medium">
  Hover me
</button>
```

Pattern: `hover:state_bg_{token}_{subtle|soft|medium|strong}`

### CSS Variables

Dùng trong inline styles hoặc custom CSS:

```tsx
style={{ backgroundColor: "var(--ds-bg-primary)", borderRadius: "var(--ds-radius-8)" }}
```

### TypeScript Token Map

Import token names với type-safe autocomplete:

```tsx
import { tokens, type TokenName } from "@frontend-team/ui-kit/token-map";

// tokens.bg_primary → "var(--ds-bg-primary)"
// tokens.fg_blue_accent → "var(--ds-fg-blue-accent)"
```

---

## 🛠️ Development Scripts

```bash
npm run dev              # Khởi động playground dev server
npm run build            # TypeScript check + Vite build
npm run tokens           # Regenerate CSS từ design-tokens.json
npm run test             # Chạy tất cả tests
npm run test:watch       # Test ở watch mode
npm run test:coverage    # Test với báo cáo coverage
npm run type-check       # TypeScript check only
npm run lint             # ESLint
```

---

## 🔄 Quy trình khi Designer cập nhật token

1. Designer export file `design-tokens.json` mới từ Figma
2. Replace file cũ tại root repo: `design-tokens.json`
3. Chạy `npm run tokens` để regenerate CSS và token map
4. Kiểm tra trong playground: `npm run dev`
5. Commit thay đổi (gồm cả file generated `src/styles/theme.css`, `src/styles/utilities.css`)
6. Publish theo quy trình bên dưới

---

## 🚢 Quy trình Publish

### Khi sửa bug hoặc thêm component mới

**1. Đảm bảo code chạy đúng**
```bash
npm test           # Tất cả tests phải pass
npm run type-check # Không có TypeScript error
npm run build      # Build thành công
```

**2. Commit với conventional commit message**

Format: `type(scope): description`

```bash
# Thêm component mới
git commit -m "feat(badge): add Badge component with 6 variants"

# Sửa bug
git commit -m "fix(input): size prop not applied to inputVariants"

# Cập nhật token
git commit -m "feat(tokens): update design tokens to v1.1.0"

# Breaking change
git commit -m "feat(select)!: change onValueChange signature for multi-select"
```

| Type | Dùng khi |
|------|----------|
| `feat` | Thêm component/tính năng mới |
| `fix` | Sửa bug |
| `perf` | Cải thiện performance |
| `refactor` | Refactor code, không thay đổi behavior |
| `docs` | Cập nhật documentation |
| `chore` | Cập nhật deps, config |

**3. Bump version và tạo CHANGELOG**
```bash
npm run release:patch   # Sửa bug: 0.1.1 → 0.1.2
npm run release:minor   # Thêm tính năng mới: 0.1.1 → 0.2.0
npm run release:major   # Breaking changes: 0.1.1 → 1.0.0
```

Lệnh này tự động:
- Tăng version trong `package.json`
- Cập nhật `CHANGELOG.md` từ commit messages
- Tạo git commit + tag (ví dụ: `v0.2.0`)

**4. Publish lên GitLab Registry**
```bash
npm publish
```

> `prepublishOnly` sẽ tự động chạy `npm test && npm run tokens && npm run build` trước khi publish. Nếu test fail, publish sẽ bị hủy.

**5. Push tag lên remote**
```bash
git push --follow-tags
```

### Quy trình đầy đủ (ví dụ)

```bash
# 1. Làm việc trên feature branch
git checkout -b feat/tooltip-component

# 2. Code + test
npm run test:watch

# 3. Commit
git add .
git commit -m "feat(tooltip): add Tooltip component with delay and side options"

# 4. Merge vào main/develop
git checkout develop && git merge feat/tooltip-component

# 5. Release
npm run release:minor
# → tạo commit "chore(release): 0.2.0" + tag "v0.2.0"

# 6. Publish
npm publish
git push --follow-tags
```

---

## 📁 Cấu trúc dự án

```
ui-kit/
├── src/
│   ├── index.ts              # Public exports
│   ├── style.css             # CSS entry point cho consumers
│   ├── components/ui/        # Tất cả components
│   ├── hooks/                # Custom hooks (useDarkMode)
│   ├── lib/                  # Utilities (cn, toast)
│   ├── styles/
│   │   ├── theme.css         # [Auto-generated] CSS variables
│   │   └── utilities.css     # [Auto-generated] Utility classes
│   └── token-map.ts          # [Auto-generated] TypeScript token map
├── scripts/
│   └── build-tokens.js       # Token generation script
├── design-tokens.json        # Source of truth từ Figma
├── state-mix.config.json     # Config cho state utility classes
└── TODO.md                   # Backlog kỹ thuật + cần phối hợp designer
```

## 📝 Thêm Component Mới

1. Tạo file trong `src/components/ui/`:
   - `{name}.tsx` — component + props interface
   - `{name}-variants.ts` — CVA variant definitions
   - `{name}.test.tsx` — Vitest + RTL tests
2. Dùng `cn()` từ `@/lib/internal` để merge classes
3. Dùng `cva()` cho variants — không hardcode colors/spacing, dùng token classes
4. Export từ `src/index.ts`
5. Thêm ví dụ vào `src/App.tsx`

## 📄 License

MIT

## 🔗 Links

- **GitLab Registry:** `https://gitlab.ikameglobal.com/api/v4/projects/1311/packages/npm/`
- **Version History:** Xem `CHANGELOG.md` hoặc git tags
